
localStorage.setItem('ordinances', JSON.stringify(ordinances));
